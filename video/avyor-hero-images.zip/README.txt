AVYOR — images pour le Hero
11 images originales : avatar + 5 plans desktop + 5 plans mobile.
Desktop : images/shot-*.png ; mobile : images/mobile/shot-*.png.
Chaque plan Runway : 3 s, 24 fps. Choisir 16:9 ou 9:16 selon le fichier.
Prompts de mouvement : runway-prompts.json.
Les écrans sont neutres pour insérer les captures réelles AVYOR dans Remotion.
Images générées par imagegen avec logo officiel comme référence. Aucun clip Runway dans cette archive.
